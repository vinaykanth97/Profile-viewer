import React from 'react'

export default function PortfolioProfile() {
    return (
        <div className="container max-w-[542px] m-auto px-4 pt-7">Test</div>
    )
}
