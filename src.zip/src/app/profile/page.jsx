"use client"
import InnerContent from '../components/InnerContent'
import { InputField, PrimaryBtn, SecondaryBtn, ToggleSwitch } from '../components/ElementUtils'
import avatarProfile from '../images/codedamn-avatar.png'

import { useRef, useState, useEffect, useContext } from 'react'
import { formValidationHandler } from '../reusable-hooks/FormValidation'
import { formContext } from '../components/formContext'


export default function Profile() {
  const ValidationSchema = {
    fieldProperty: {
      displayName: {
        max: 8,
        // min: 2,
        // notEmpty: true,
        // errorId: 'Display Name',
        // errorWhenEmpty: 'This is a required field',
        // errorOnMin: 'Minimum 2 characters',
        errorOnMax: 'Maximum 8 characters',
        // errorOnRegex: 'Shoud Match the validation',
        notEmpty: true,
        errorWhenEmpty: 'This is a required field',
      },
      about: {
        max: 8,
        notEmpty: true,
        errorWhenEmpty: 'This is a required field',
        errorOnMax: 'Maximum 8 characters',
      },
      profession: {
        notEmpty: true,
        errorWhenEmpty: 'This is a required field',
      }
    },
    validationOnChange: true,
    validationOnBlur: true,
    validationOnFocus: true,
    validationOnSubmit: true
  }
  const useFormContext = useContext(formContext)
  const { initialInputValue, setInitialInputValue, error, setError } = useFormContext
  const { handleOnChange, handleOnBlur, handleOnFocus, handleOnSubmit } = formValidationHandler(ValidationSchema, initialInputValue, setInitialInputValue, error, setError)


  const handleOnInput = (e) => {
    handleOnChange(e)
  }
  const validateOnBlur = (e) => {
    handleOnBlur(e)
  }
  const validateOnFocus = (e) => {
    handleOnFocus(e)
  }
  const formRef = useRef(null)
  const ValidateOnSubmit = (e) => {
    handleOnSubmit(e)
  }
  useEffect(() => {
    let allFormDatas = Object.fromEntries(new FormData(formRef.current))
    setInitialInputValue?.(allFormDatas)
    let validationFieldProperty = Object.keys(ValidationSchema.fieldProperty)
    setError?.(Object.assign({ ...error }, ...validationFieldProperty.map(item => {
      return {
        ...error,
        [item]: { errorSignal: true, errorMsg: '' },
      }
    })))
  }, [])


  return (
    <>
      <InnerContent>
        <form onSubmit={(e) => ValidateOnSubmit(e)} ref={formRef}>
          <div className="flex items-center mb-7">
            <figure className='mr-6'>
              <img src={avatarProfile.src} alt="avatar Profile" className='w-[72px] h-[72px]' />
            </figure>
            <div className="button-utils flex gap-3">
              <label htmlFor='fileupload' className='py-[10px] px-[16px] bg-primary-600 text-[#fff] rounded-[10px] font-semibold'>Upload new picture</label>
              <input type="file" className='hidden' id="fileupload" name='profileImage' onChange={handleOnInput} />
              <SecondaryBtn text="Delete" btnType="button" />
            </div>
          </div>
          {/* Field Items */}
          <InputField labelName="Display name" fieldName="displayName" type="text"
            onChange={handleOnInput} onBlur={validateOnBlur} onFocus={validateOnFocus} />
          <p>{error?.displayName?.errorMsg}</p>
          <div className="mb-7" >
            <label className="block text-black font-semibold mb-1">About</label>
            <textarea rows="3" className="border-solid border-zink-200 border-2 w-[100%]  p-2 text-black resize-none" name='about' defaultValue={''} onChange={handleOnInput} onBlur={validateOnBlur} onFocus={validateOnFocus}></textarea>
            <p>{error?.about?.errorMsg}</p>
          </div >
          <InputField labelName="Profession" fieldName="profession" type="text" onChange={handleOnInput} onBlur={validateOnBlur} onFocus={validateOnFocus} />
          <p>{error?.profession?.errorMsg}</p>
          <InputField labelName="Date of birth" fieldName="dateofbirth" type="date" onChange={handleOnInput} onBlur={validateOnBlur} />

          <div className="mb-7" >
            <label className="block text-black font-semibold mb-1">Gender</label>
            <select name="gender" onChange={handleOnInput} className="border-solid border-zink-200 border-2 w-[100%]  p-2 text-black" onBlur={validateOnBlur}>
              <option value="">Select your Gender</option>
              <option value="Male">Male</option>
              <option value="Female">Female</option>
            </select>
          </div>
          <div className="mb-[50px]">
            <h2 className="text-4xs text-black font-bold mb-2">Section visibility</h2>
            <p className='mb-8'>Select which sections and content should show on your profile page.</p>

            <ToggleSwitch title="Followers and following" subtitle="Shows your followers and the users you follow on codedamn" fieldName="followers" onChange={handleOnInput} />
            <ToggleSwitch title="XP" subtitle="Shows the XP you have earned" fieldName="xpEarned" onChange={handleOnInput} />
            <ToggleSwitch title="Achievement badges" subtitle="Shows your relative percentile and proficiency" fieldName="achievementBadges" onChange={handleOnInput} />
          </div>
          <div className='flex justify-end items-center gap-5 pb-10'>
            <SecondaryBtn text="Cancel" btnType="button" />
            <PrimaryBtn text="Save changes" btnType="submit" />
          </div>
        </form>

      </InnerContent>
    </>
  )
}
