




export const formValidationHandler = (ValidationSchema, initialInputValue, setInitialInputValue, error, setError) => {

    return {
        handleOnChange: function (e) {
            let targetName = e.target.name,
                targetValue = e.target.value;
            let { validationOnChange, fieldProperty } = ValidationSchema
            setInitialInputValue({
                ...initialInputValue,
                [targetName]: targetValue,
            })
            if (validationOnChange) {
                ValidationExecutor(targetName, targetValue, fieldProperty[targetName], setError, error)
            }
        },
        handleOnBlur: function (e) {
            let targetName = e.target.name,
                targetValue = e.target.value;
            let { validationOnBlur, fieldProperty } = ValidationSchema
            setInitialInputValue({
                ...initialInputValue,
                [targetName]: targetValue,
            })
            if (validationOnBlur) {
                ValidationExecutor(targetName, targetValue, fieldProperty[targetName], setError, error)
            }
        },
        handleOnFocus: function (e) {
            let targetName = e.target.name,
                targetValue = e.target.value;
            let { validationOnFocus, fieldProperty } = ValidationSchema
            setInitialInputValue({
                ...initialInputValue,
                [targetName]: targetValue,
            })
            if (validationOnFocus) {
                ValidationExecutor(targetName, targetValue, fieldProperty[targetName], setError)
            }
        },
        handleOnSubmit: function (e) {
            e.preventDefault()
            let valuesOfAllField = Object.entries(initialInputValue)
            let { fieldProperty } = ValidationSchema

            valuesOfAllField?.forEach(([key, value]) => {
                ValidationExecutor(key, value, fieldProperty[key], setError, error)
            })
        }
    }
}

function ValidationExecutor(key, value, fieldProperty, setError, error) {

    if (fieldProperty !== undefined) {

        if (value.length <= 2 && fieldProperty?.hasOwnProperty('notEmpty')) {
            console.log('empty chec')
            setError(prev => {
                console.log(prev)
                // prev[key] = { errorSignal: true, errorMsg: fieldProperty?.errorWhenEmpty }
                if (prev[key] !== undefined) {
                    prev[key].errorSignal = true
                    prev[key].errorMsg = fieldProperty?.errorWhenEmpty;
                }

                return prev
            })
        } else {
            console.log('Inside else')
            setError(prev => {
                if (prev[key] !== undefined) {
                    prev[key].errorSignal = false
                    prev[key].errorMsg = '';
                }

                return prev
            })
        }


        // if (value.length < fieldProperty?.min && fieldProperty?.hasOwnProperty('min')) {
        //     console.log('Inside if')
        //     setError(prev => {
        //         prev[key] = { errorSignal: true, errorMsg: fieldProperty?.errorOnMin }
        //         return prev
        //     })
        // } else {
        //     console.log('Inside else')
        //     setError(prev => {
        //         prev[key] = { errorSignal: false, errorMsg: '' }
        //         return prev
        //     })
        // }
    }

}