"use client";
const { createContext, useState } = require("react");

export const formContext = createContext()
export const FormContextProvider = ({ children }) => {
    const [initialInputValue, setInitialInputValue] = useState({})
    const [error, setError] = useState({})
    
    return (
        <formContext.Provider value={{ initialInputValue, setInitialInputValue, error, setError }}>{children}</formContext.Provider>
    )
}