import InnerContent from '../components/InnerContent'

export default function Resume() {
    return (
        <>
            <InnerContent>
                <h1>Resume</h1>
            </InnerContent>
        </>
    )
}
